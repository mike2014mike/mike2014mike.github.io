---
layout:     post
title:      親子停車位識別證
date:       2018-08-02 12:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby

---
![新北市親子停車位識別證](https://i.imgur.com/OaUYVc6.jpg)

### 「親子停車位識別證」之亂
* [228格卻發30萬張停車證 台中親子停車恐「僧多粥少」](https://news.housefun.com.tw/news/article/455709203017.html)


### 新北市政府交通局公告
```
詳細報導：孕婦兒童停車證 新北搶先公布7/27發放

時間：107年7月27日起可領取。

攜帶資料：孕婦或兒童健康手冊

領取地點：
1. 新北市交通局秘書室(板橋區中山路 1 段 161 號 10 樓)。
2. 新北市交通局台北橋捷運站辦公室(三重區重新路 1 段 108 號 4 樓)。
3. 新北市交通局轄管 106 處停車場及 6 處停車管理場。
(以上地點午休時間 12 時至 13 時 30 分不提供領取)

備註：107年8月1日起停車位識別證會隨新發之孕婦手冊或兒童手冊隨冊夾發無須申請。

資料來源：新北市政府
```

### 參考
* [新北市政府交通局：孕婦及育有6歲以下兒童者之停車位](https://www.traffic.ntpc.gov.tw/home.jsp?id=265&parentpath=0,4,29)
* [停車位識別證 八月起可申請](https://tw.news.yahoo.com/%E5%AD%95%E5%A9%A6%E8%A6%AA%E5%AD%90%E5%81%9C%E8%BB%8A%E4%BD%8D%E8%AD%98%E5%88%A5%E8%AD%89-%E5%85%AB%E6%9C%88%E8%B5%B7%E5%8F%AF%E7%94%B3%E8%AB%8B-094011162.html)
* [106 處停車場及 6 處停車管理場](https://www.traffic.ntpc.gov.tw/userfiles/1130901/files/%E6%9C%AC%E5%B8%82%E3%80%8C%E5%AD%95%E5%A9%A6%E3%80%81%E8%82%B2%E6%9C%896%E6%AD%B2%E4%BB%A5%E4%B8%8B%E5%85%92%E7%AB%A5%E8%80%85%E5%81%9C%E8%BB%8A%E4%BD%8D%E8%AD%98%E5%88%A5%E8%AD%89%E3%80%8D%E7%99%BC%E8%AD%89%E5%9C%B0%E9%BB%9E(4).pdf)