---
layout:     post
title:      【手遊】Pokemon GO 精靈寶可夢攻略彙整
date:       2018-07-14 09:37:19
author:     Mike Chen
summary:    
categories: Game
thumbnail:  gamepad
tags:
 - Game
 - Pokémon
---


![Pokémon Go](https://i.imgur.com/hUxY0Us.jpg)

以下攻略是四處蒐集的文章圖表，但因為是很久以前蒐集的，來源已經不可考，所以我這邊也無法備註，若有發現您的文章，還請告知文章連結，我會再補上來源，謝謝。

> 遊戲角色名稱：酷壽司


### 精靈寶可夢技能表

![精靈寶可夢技能表](https://i.imgur.com/pveYtBz.png)

### 精靈寶可夢資料規格書

[點我下載(PDF)](https://www.dropbox.com/s/czoumcidbph3by7/Pokemon%20%E7%B2%BE%E9%9D%88%E8%B3%87%E6%96%99%E4%B8%80%E8%A6%BD%E8%A1%A8-A4%E6%A9%AB%E5%88%97%E5%8D%B0%E7%89%88.pdf?dl=0)

