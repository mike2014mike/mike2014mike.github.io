---
layout:     post
title:      寶寶甩肩舞
date:       2018-07-30 12:37:19
author:     Mike Chen
summary:    Coincidance
categories: Baby
thumbnail:  heart
tags:
 - Baby
 - Coincidance

---

<div class="videoWrapper">
    <iframe src="https://www.youtube.com/embed/qR5sA6a50Wc" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>

這是將我兒子日常拍攝的影片擷取部分律動像【Coincidance 甩肩舞】的片段，重複播放，配上音樂，感覺蠻合適的。

主演：我五個月大的兒子

甩肩舞影片原網址：[https://youtu.be/nBHkIWAJitg](https://youtu.be/nBHkIWAJitg)<br>
翻譯影片來源：[https://youtu.be/QTDrIONw2M0](https://youtu.be/QTDrIONw2M0)

<hr>
寶寶的貼圖：[https://goo.gl/VupQob](https://goo.gl/VupQob)
