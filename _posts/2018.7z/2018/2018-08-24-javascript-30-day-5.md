---
layout:     post
title:      JavaScript 30 - Day 5.Flex Panel Gallery
date:       2018-08-24 10:37:19
author:     Mike Chen
summary:    
categories: Study
thumbnail:  code
tags:
 - JavaScript
 - CSS
 - Flex
---


### #5.Flex Panel Gallery
* [實作-JS](https://mike2014mike.github.io/js30/05 - Flex Panel Gallery/index-mike-js.html)
* [實作-jQuery](https://mike2014mike.github.io/js30/05 - Flex Panel Gallery/index-mike-jq.html)
* [實作-純CSS](https://mike2014mike.github.io/js30/05 - Flex Panel Gallery/index-mike-pure-css.html)



### 參考
* [Javascript 30 #4 with Amos](https://www.youtube.com/watch?v=jYH4AjGHoeQ)
* [JavaScript 30](https://javascript30.com/)
* [GitHub - Javascript 30](https://github.com/wesbos/JavaScript30)