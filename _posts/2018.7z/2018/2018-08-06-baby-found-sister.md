---
layout:     post
title:      寶寶終於找到保母
date:       2018-08-06 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---


![保母家](https://i.imgur.com/0lJgGgK.jpg)

最近忙著找寶貝兒子的保母，比較了幾位，終於確認了。寶寶似乎蠻喜歡這位保母的，希望她可以細心呵護我們的寶貝。