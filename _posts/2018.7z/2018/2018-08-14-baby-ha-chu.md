---
layout:     post
title:      「哈啾」打噴嚏聲讓寶寶狂笑
date:       2018-08-14 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---

無意間發現，我兒子只要聽到「哈啾」打噴嚏聲就會嘎嘎大笑。

P.S. 我還在感冒所以還戴著口罩

<div class="videoWrapper">
    <iframe src="https://www.youtube.com/embed/0m5xGgAWvZM" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>