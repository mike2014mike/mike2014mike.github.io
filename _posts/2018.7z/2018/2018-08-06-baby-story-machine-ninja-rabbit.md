---
layout:     post
title:      寶寶故事機-忍者兔
date:       2018-08-06 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---


![忍者兔](https://i.imgur.com/Kp5QEYV.jpg)

最近購買了故事機-忍者兔(黃色)，來陪伴我兒子，唱歌、說故事給他聽。忍者兔耳朵是軟的，是讓寶寶咬的。但我家寶貝兒子不咬耳朵，先拿布書敲一敲人家，手拍一拍人家，最後一直狂吻人家。

<div class="videoWrapper">
    <iframe src="https://www.youtube.com/embed/0m5xGgAWvZM" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>