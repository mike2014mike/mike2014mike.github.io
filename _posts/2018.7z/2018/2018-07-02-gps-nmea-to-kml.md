---
layout:     post
title:      NMEA 轉 KML
date:       2018-07-02 09:37:19
author:     Mike Chen
summary:    
categories: Work
thumbnail:  map-marked-alt
tags:
 - GIS
 - GPS
---

### 需求

NMEA 是大部份的 GPS receiver 的資料格式，可透過下列網址轉為KML。


### 解法

* 可將 NMEA 轉為 KML 的網站：http://www.h-schmidt.net/NMEA/