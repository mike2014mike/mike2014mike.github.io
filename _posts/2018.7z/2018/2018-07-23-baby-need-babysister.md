---
layout:     post
title:      寶寶需要保母
date:       2018-07-23 10:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---


> 不知道貼在這裡有沒有用，還是貼貼看吧！


### 徵保母
![baby](https://lh3.googleusercontent.com/e3AyX82youRT05c5CffFNCd5hTMiqiyaY7oavEblg174Jr2oZjcEnA_ASEEzETHQokP8qj5Ez6pa771yT4WejZI611rahgiApBZRWknJ8ngeN2cbONTPdMHfJFqwsaJmzZvP9FGTGzGEAQcD2hDXXAgrUypyde9dsZFYzXUDjVZrzrrnDu-ppIaE7Oh2KWvEQJ-iTemrnRIZcMHsr05bVxS9XmhescnTs6aYH6WujLcadElUULjORdZTBDEjNV2QGn51pLok8Nx52j8CEXmW7ILJdQBiGkJRVA0TEHJ9z4u9OPgZ8bHBkjoCupo1Eba2li9TGdm8VCKcykOOwRn5ojRWNTeTOSKILbefCKgvIEZDCetlQyJgQ_ys1SQKXhWCE6FXZxeRXHotIFYMy8jwbowzKedURhb0bOz4RZ0h30LfWz1qwUvPI_LaJHtREjdC4l1u7soGs9HjtDYOuLBw7Iy4ejOiDDVXQ0QDXBJez0q8BH3H22NbuavCscHcGhucBav2B5J8DHaI3EL87azTq4j2JXYBZMWUQ88CFZBYFyWKbFAPH2-54AVKkAlqzTTw8_5JA2ldjjy1jHA6PdxIeFFScFZp5x8v5J581-18=w1099-h618-no)
寶寶(男)今年2月生，目前5個月大，預計今年10月有托育需求。
* 托育時間：07:30~18:30，我們去接他時，希望已經洗好澡。
* 托育地點：新北市樹林區啟智街，希望找近一點的在宅保母。
* 寶寶很 `怕熱` ，需要全日 `開冷氣` ，不然過一陣子 `濕疹` 就會冒出來。
* 寶寶若大號，還請務必幫他清洗小屁屁，若只用濕紙巾會很容易紅屁屁。
* 寶寶會 `過敏` ，常見容易引起過敏的東西與食物，請勿讓他接觸與食用。


```
希望可以找到有愛心、耐心、貼心、細心、包容心的保母。
```

<hr>
我另外在下面這些網站，也都有註冊或刊登。

* [POBI波比保母](https://pobi.com.tw/)
* [OurKids育兒樂](http://www.ourkids.com.tw/nanny/NannyList.asp?NannyType=1)
* [108保母銀行](http://www.108.com.tw/)
* [小夫妻照顧網](http://457.com.tw/work_detail.php?id=60228)
* [Bananny托育小幫手](https://bananny.co/billboards/5197)

<hr>
### 行情價
有稍微查一下，新北的行情大概如下，所以若超出這個範圍，就不列入考慮囉！
![price](https://i.imgur.com/iasTBk7.png)