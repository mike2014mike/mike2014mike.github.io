---
layout:     post
title:      寶貝兒子的影分身之術！
date:       2018-08-15 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---

![影分身之術](https://i.imgur.com/4noMkms.jpg)

### 寶貝兒子的影分身之術！
昨日下班在看好久沒看的火影忍者新世代 - 博人傳，突發奇想幫兒子拍個影分身之術的照片。

### 使用工具
* 手機 * 1
* 三腳架 * 1
* PhotoImpact軟體 * 1