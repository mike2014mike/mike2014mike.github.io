---
layout:     post
title:      寶貝兒子叫爸爸了！
date:       2018-07-28 12:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby

---


<div class="videoWrapper">
    <iframe src="https://www.youtube.com/embed/vhnJOBRiqnk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>


這天我兒子躺在嬰兒床上，自己發出類似爸爸的聲音，讓我又驚又喜。

<hr>
寶寶的貼圖：[https://goo.gl/VupQob](https://goo.gl/VupQob)
