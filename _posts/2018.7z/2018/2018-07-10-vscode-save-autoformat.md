---
layout:     post
title:      VSCode存檔自動縮排
date:       2018-07-10 10:37:19
author:     Mike Chen
summary:    VSCode存檔自動縮排
categories: Work
thumbnail:  vscode
tags:
 - VSCode
 - Emmet
---

檔案>喜好設定>設定

```
"editor.formatOnSave": true
```