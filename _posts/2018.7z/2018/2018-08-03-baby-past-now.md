---
layout:     post
title:      寶寶之古今對照
date:       2018-08-03 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---

> 30多年前，爺爺抱著爸爸  
> 今天，爸爸抱著你

![古今對照](https://i.imgur.com/RQNqHuO.jpg)