---
layout:     post
title:      什麼是Jekyll?
date:       2018-07-03 10:32:18
summary:    說明甚麼是Jekyll.
categories: Other
thumbnail: jekyll
tags:
 - Jekyll
---

## Jekyll 介紹

Jekyll是基於Ruby Gem的解析引擎，能夠將樣板、liquid 語言、markdown轉換為 `靜態網頁` 的產生器。
[http://jekyllrb.com/](http://jekyllrb.com/)

## 特色
* No more databases 不需要資料庫
* Liquid Template 動態模板
* Free hosting with GitHub Pages 只要學會git push 就可以丟到github page上
* Markdown 好編寫

## 參考
[Jekyll目录结构和运行机理](https://blog.csdn.net/HopefulLight/article/details/78366374)