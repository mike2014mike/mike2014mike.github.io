---
layout:     post
title:      家樂福樹林店父親節活動-父子臉比一比
date:       2018-07-31 12:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby

---

### 活動說明

```
🎊父親節快樂-父子/女 臉比一比🎊

⚠️⚠️緊急通告⚠️⚠️
🔴參加人數太踴躍啦！
參加人數限制從10組➡️50組
額滿即沒有參加獎囉🔚

1. 7/28-8/1 收集10組～50組參選活動照片(父女/子合照照片)，上傳於FB粉絲專頁，前50名參加者有參加獎喔🎁

2. 8/1-8/4 活動照片將挑選按讚最多 的10組，於LINE 粉絲團進行投票，第一名將可獲得價值888元超值好禮🏆

3. 8/5-8/8 可以和小編聯絡您的領獎時間喔😘
```

### 活動海報

<div class="col-sm-6 col-xs-12">
    <img src="https://i.imgur.com/wCel0ce.jpg" width="100%">
</div>

<div class="col-sm-6 col-xs-12">
    <img src="https://i.imgur.com/In2eqE1.jpg" width="100%">
</div>



### 幫忙按讚

If you have some free time, please go to the following link, and find the photo of my son & me, then give us a like.Thanks!<br>
有空的朋友請幫忙到下面活動網址，找到我跟兒子的照片（如下圖）按個讚喔，謝謝！<br>
[【活動網址】](http://0rz.tw/K0Ksv)

![家樂福樹林店活動](https://i.imgur.com/S8lSK8f.jpg)