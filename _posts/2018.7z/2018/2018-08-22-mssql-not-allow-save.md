---
layout:     post
title:      SQL Server出現「不允許儲存變更」的處理方法
date:       2018-08-22 09:37:19
author:     Mike Chen
summary:    
categories: Work
thumbnail:  database
tags:
 - Database
 - MSSQL
---

### 問題

當遇到SQL Server出現「不允許儲存變更」的對話框

### 解法

1. 開啟SQL Server Management Studio
2. 工具-->選項-->Designers(設計師)-->資料表和資料庫設計工具-->防止儲存需要資料表重建的變更-->取消勾選 即可！
