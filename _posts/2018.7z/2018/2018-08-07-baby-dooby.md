---
layout:     post
title:      DOOBY 大眼蛙水壺
date:       2018-08-07 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Batch-file
---

![寶寶喝水](https://i.imgur.com/IdLSxZH.jpg)

跟風買給寶寶 DOOBY 大眼蛙水壺<br>
五個月大的寶寶會自己喝水囉！



### 參考
* [dooby大眼蛙神奇喝水杯─優點缺點通通告訴你](http://elaborate.pixnet.net/blog/post/378957875-%E3%80%90%E8%82%B2%E5%85%92%E3%80%91dooby%E5%A4%A7%E7%9C%BC%E8%9B%99%E7%A5%9E%E5%A5%87%E5%96%9D%E6%B0%B4%E6%9D%AF%E2%94%80%E5%84%AA%E9%BB%9E%E7%BC%BA%E9%BB%9E%E9%80%9A)
