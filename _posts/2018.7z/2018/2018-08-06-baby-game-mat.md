---
layout:     post
title:      寶寶遊戲地墊
date:       2018-08-06 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---

![遊戲地墊](https://i.imgur.com/cixNac7.jpg)

最近購買了遊戲地墊，一面是夢幻樂園、另一面是水果字母，讓我寶貝兒子在客廳也可以安全地滾來滾去、爬來爬去。