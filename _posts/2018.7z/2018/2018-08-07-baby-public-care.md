---
layout:     post
title:      公托通知錄取，但...
date:       2018-08-07 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---


今天上班的時候，接到[文林公托中心](https://www.facebook.com/%E6%96%B0%E5%8C%97%E5%B8%82%E6%A8%B9%E6%9E%97%E6%96%87%E6%9E%97%E5%85%AC%E5%85%B1%E6%89%98%E8%82%B2%E4%B8%AD%E5%BF%83-1719719898322218/)通知九月份有名額釋出，9/3入學，明天中午前需回覆是否要入學。<br>
8/4 才剛跟保母簽約，才隔三天就收到錄取通知，真的是很猶豫是否要讓寶寶去公托。<br>
<br>
但考慮到寶寶現在皮膚濕疹我們就很心疼了，<br>
如果送去公托，還因群聚感染感冒，卡痰鼻塞，那還得了！<br>
而且到九月份，寶寶才6個月大，根本不會擤鼻涕、吐痰，很容易窒息<br>
<br>
為了寶寶的健康和安全，我們還是決定寧可多花些費用讓寶寶去保母那邊吧！


### 參考
* [寶寶送公托，家長您想清楚了嗎？](http://sherry19800525.pixnet.net/blog/post/44114344-%E5%AF%B6%E5%AF%B6%E9%80%81%E5%85%AC%E6%89%98%EF%BC%8C%E5%AE%B6%E9%95%B7%E6%82%A8%E6%83%B3%E6%B8%85%E6%A5%9A%E4%BA%86%E5%97%8E%3F%3F%3F)
* [該找保母還是托嬰中心？七點差異告訴你！](https://mamaclub.com/learn/%E8%A9%B2%E6%89%BE%E4%BF%9D%E6%AF%8D%E9%82%84%E6%98%AF%E6%89%98%E5%AC%B0%E4%B8%AD%E5%BF%83%EF%BC%9F%E4%B8%83%E9%BB%9E%E5%B7%AE%E7%95%B0%E5%91%8A%E8%A8%B4%E4%BD%A0%EF%BC%81/)
* [托嬰中心、幼稚園、保母、給婆婆帶大評比](http://hipaya.pixnet.net/blog/post/46875091-%E6%89%98%E5%AC%B0%E4%B8%AD%E5%BF%83%E3%80%81%E5%B9%BC%E7%A8%9A%E5%9C%92%E3%80%81%E4%BF%9D%E6%AF%8D%E3%80%81%E7%B5%A6%E5%A9%86%E5%A9%86%E5%B8%B6%E5%A4%A7%E8%A9%95%E6%AF%94%3A)