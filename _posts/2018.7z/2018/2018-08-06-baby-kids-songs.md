---
layout:     post
title:      寶寶英文兒歌(含改編)
date:       2018-08-06 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---

這幾首兒歌我兒子特別喜歡，其中幾首我也做了改編，在此紀錄。

* [Old MacDonald Had A Farm](https://www.youtube.com/watch?v=lxBdN_8ltR8)

```js
Old macdonald had a farm
yi a yi a o

and on the farm he had a cat
yi a yi a o

with a miaomiao here
and miaomiao there

here miao there miao
everywhere miaomiao

Old macdonald had a farm
yi a yi a o


//==以下改編==
Old macdonald had a farm
yi a yi a o

and on the farm he had a "baby"
yi a yi a o

with a "wawa" here
and "wawa" there

here "wa" there "wa"
everywhere "wawa"

Old macdonald had a farm
yi a yi a o

```

* [Five Little Ducks](https://www.youtube.com/watch?v=5NUiGQpQFAM)

```js
Five little ducks went out one day 
Over the hills and far away
Mother duck said, "Quack, quack, quack, quack"
But only four little ducks came back

//==以下改編==
One little "baby" went out one day 
Over the hills and far away
Mother "美香" said, "baby 快回來"
"你的奶粉已經泡好了"

```

* [I Love the Mountains](https://www.youtube.com/watch?v=VCPg3Bx1vf0)

```js
I love the mountains 
I love the rolling hills 
I love the flowers
I love the daffodils(水仙)
I love the fireside(暖爐)
When all the lights are low 
(當夜幕降臨)

Boom-dee-a-da, boom-dee-a-da, boom-dee-a-da, boom-dee-yay
Boom-dee-a-da, boom-dee-a-da, boom-dee-a-da, boom-dee-yay
```





### 常放給他看的英文兒歌影片

<div class="videoWrapper">
    <iframe src="https://www.youtube.com/embed/_EdEB_BuSFw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>

```
00:00:00 ABC字母歌
00:01:55 兔子舞
00:03:02 Jingle Bells
00:04:22 Bingo
00:06:01 Mary had a little lamb (瑪莉有隻小綿羊)
00:07:26 London Bridge (倫敦鐵橋)
00:08:33 Ten little Indian boys
00:10:22 Fly Birdie Fly (我是隻小小鳥)
00:12:05 Apple Tree (綠油精)
00:13:20 The fox
00:15:23 Twinkle twinkle Little Star (一閃一閃亮晶晶)
00:16:49 Five Little Ducks
00:18:48 Old MacDonald Had A Farm (王老先生有塊地)
00:20:46 Chenparty (Häschenparty 德國兒歌)
```