---
layout:     post
title:      歡迎來到麥克的筆記本
date:       2018-07-01 09:37:19
author:     Mike Chen
summary:    歡迎來到麥克的筆記本
categories: Other
thumbnail:  heart
tags:
---
> 小小工程師，努力朝全端工程師(Full Stack Developer)邁進！

歡迎來到[麥克的筆記本][1]，這裡主要紀錄一些學習筆記與小技巧，包含：
* 工作相關：Javascript、jQuery、CSS、RWD、Android、Linux、SQL、SEO等各種工作上遇到的問題與解決方案，方便日後查閱。
* 武林秘笈：電腦系統、網路與程式使用之小技巧。
* 寶寶成長日記：紀錄寶貝兒子的相關訊息。
* 遊戲攻略：工作之餘，小弟都以玩遊戲紓壓，所以這裡也會記錄一些遊戲攻略，當作參考。

希望這些資料可以幫助到各位朋友，謝謝。

Have a nice day! ^_^

[1]: https://mike2014mike.github.io/
