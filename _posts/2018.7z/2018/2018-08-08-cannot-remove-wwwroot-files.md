---
layout:     post
title:      無法刪除 wwwroot 底下資料之解法
date:       2018-08-08 09:37:19
author:     Mike Chen
summary:    
categories: Tips
thumbnail:  windows
tags:
 - wwwroot
---

無法刪除 `C:\inetpub\wwwroot` 底下的資料？

只要將 `World Wide Web Publishing Service` 服務停止即可。