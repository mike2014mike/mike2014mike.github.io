---
layout:     post
title:      寶寶跳恰恰
date:       2018-07-06 12:37:19
author:     Mike Chen
summary:    寶寶跳恰恰
categories: Baby
thumbnail:  heart
tags:
 - Baby

---

<div class="videoWrapper">
    <iframe src="https://www.youtube.com/embed/c1PvzPzNxbI" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>

這是將我兒子日常拍攝的影片擷取部分律動像【恰恰】的片段，重複播放，配上音樂，感覺蠻合適的。

主演：我四個月大的兒子

<hr>
寶寶的貼圖：[https://goo.gl/VupQob](https://goo.gl/VupQob)
