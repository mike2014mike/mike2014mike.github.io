---
layout:     post
title:      AVG 導致區網連線錯誤碼 0x80070035
date:       2018-08-13 09:37:19
author:     Mike Chen
summary:    
categories: Work
thumbnail:  windows
tags:
 - AVG
---

### 處理無法連區網問題
1. 錯誤訊息：Windows 無法存取\\192.168.xx.xx 錯誤碼 0x80070035
2. 解決辦法：設定防毒軟體AVG，右鍵 > Firewall > Firewall設定檔 > 網域內電腦。