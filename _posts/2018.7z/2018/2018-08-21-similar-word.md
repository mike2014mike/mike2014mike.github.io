---
layout:     post
title:      「巿」和「市」傻傻分不清
date:       2018-08-21 09:37:19
author:     Mike Chen
summary:    
categories: Work
thumbnail:  database
tags:
 - Database
 - MSSQL
---

### 問題

專案資料庫中，縣市名稱無法正常篩選。

### 解法

* 有些資料的字是「巿」(ㄈㄨˊ)，應統一改為「市」(ㄕˋ)。
* 下面放大點看

# 巿
# 市