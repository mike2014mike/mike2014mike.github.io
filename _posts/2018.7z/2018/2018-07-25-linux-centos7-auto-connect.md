---
layout:     post
title:      CentOS 7 設定開機自動連線
date:       2018-07-25 10:37:19
author:     Mike Chen
summary:    
categories: Work
thumbnail:  linux
tags:
 - Linux
 - CentOS
---

![開機自動連線](https://i.imgur.com/IS1Eeoa.jpg)