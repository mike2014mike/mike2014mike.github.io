---
layout:     post
title:      Python - numpy 使用方式
date:       2018-09-18 09:37:19
author:     Mike Chen
summary:    
categories: Study
thumbnail:  python
tags:
 - Python
 - numpy
---

### numpy 使用方式
* numpy創建array
![numpy創建array](https://i.imgur.com/wItupVt.png)

* numpy基礎運算
![numpy基礎運算](https://i.imgur.com/hYcv6Sv.png)

* numpy array分割
![numpy array分割](https://i.imgur.com/cff1qLE.png)

* numpy array合併
![numpy array合併](https://i.imgur.com/gVQCl8x.png)

* numpy索引
![numpy索引](https://i.imgur.com/OpmEK7y.png)

* numpy copy & deep copy
![numpy copy & deep copy](https://i.imgur.com/773HnGE.png)