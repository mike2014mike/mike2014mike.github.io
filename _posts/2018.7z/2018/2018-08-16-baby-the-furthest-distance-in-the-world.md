---
layout:     post
title:      世界上最遙遠的距離
date:       2018-08-16 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---

![世界上最遙遠的距離](https://i.imgur.com/GzvmKW8.jpg)

### 寶貝兒子 - 世界上最遙遠的距離

```
昨日老婆擠好奶拿裝好ㄋㄟㄋㄟ的奶瓶給我，讓我餵寶寶。
以往我都是直接餵，但今天的我比較調皮一點，將奶瓶放在他面前，想看看他的反應。
這六格漫畫就這樣誕生了XD
```

### 使用工具
* 手機 * 1
* PhotoImpact軟體 * 1