---
layout:     post
title:      【手遊】旅行青蛙
date:       2018-07-07 09:37:19
author:     Mike Chen
summary:    
categories: Game
thumbnail:  gamepad
tags:
 - Game
---


![旅行青蛙](https://i.imgur.com/TLVkTn6.jpg)

前陣子很流行的青蛙養成遊戲，雖然我已經沒玩了，這邊還是分享一下我的存檔。
如果你覺得四葉草總是不夠用，可以直接拿我砍遊戲前的存檔去玩(限Android)。

[麥克存檔](https://mike2014mike.github.io/sample/2018-07-07/Tabikaeru.sav)

### 存檔路徑

```
PATH = "/sdcard/Android/data/jp.co.hit_point.tabikaeru/files/"
```

### 攻略
* [旅行青蛙明信片與道具取得對照表](https://applealmond.com/posts/26337)