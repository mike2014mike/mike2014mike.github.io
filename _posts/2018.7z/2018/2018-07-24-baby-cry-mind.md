---
layout:     post
title:      寶寶心事誰人知
date:       2018-07-24 12:37:19
author:     Mike Chen
summary:    寶寶心事誰人知
categories: Baby
thumbnail:  heart
tags:
 - Baby

---

<div class="videoWrapper">
    <iframe src="https://www.youtube.com/embed/6tX2nBNHE8I" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>

這是我兒子日常拍攝的影片，聲音像是欲言又止，有心事想哭的感覺，配上音樂，感覺蠻合適的。

主演：我五個月大的兒子<br>
音樂：心事誰人知

<hr>
寶寶的貼圖：[https://goo.gl/VupQob](https://goo.gl/VupQob)
