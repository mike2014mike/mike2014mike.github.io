---
layout:     post
title:      TeamViewer斷線後登出Windows之解法
date:       2018-08-02 09:37:19
author:     Mike Chen
summary:    
categories: Work
thumbnail:  sign-out-alt
tags:
 - TeamViewer
---

某次更新後，TeamViewer遠端斷線後會自動登出Windows，在某些情況下我們是不希望它登出的，該如何設定呢？

### 手機版

* 設定->安全性
* 鎖定遠端電腦取消即可

### PC版

* 其他->選項->進階->顯示進階選項->連線到其他電腦的進階設定
* 鎖定遠端電腦 設定成 「永不」