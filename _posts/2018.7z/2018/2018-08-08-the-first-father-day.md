---
layout:     post
title:      第一次過父親節
date:       2018-08-08 09:37:19
author:     Mike Chen
summary:    
categories: Baby
thumbnail:  heart
tags:
 - Baby
---

> 30多年前，爺爺將爸爸舉高高  
> 今天父親節，爸爸也將你舉高高

![父親節快樂](https://i.imgur.com/3NmXCAM.jpg)